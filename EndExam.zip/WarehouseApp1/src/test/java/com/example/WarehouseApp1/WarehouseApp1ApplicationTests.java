package com.example.WarehouseApp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
