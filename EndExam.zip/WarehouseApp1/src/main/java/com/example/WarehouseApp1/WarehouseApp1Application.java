package com.example.WarehouseApp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WarehouseApp1Application {

    public static void main(String[] args) {
        SpringApplication.run(WarehouseApp1Application.class, args);
    }
}

